//2
long copyLSB(long);
long test_copyLSB(long);
long dividePower2(long, long);
long test_dividePower2(long, long);
long distinctNegation(long);
long test_distinctNegation(long);
long anyEvenBit(long);
long test_anyEvenBit(long);
//3
long isLessOrEqual(long, long);
long test_isLessOrEqual(long, long);
long replaceByte(long, long, long);
long test_replaceByte(long, long, long);
long conditional(long, long, long);
long test_conditional(long, long, long);
long bitMask(long, long);
long test_bitMask(long, long);
//4
long isPalindrome(long);
long test_isPalindrome(long);
long trueFiveEighths(long);
long test_trueFiveEighths(long);
long logicalNeg(long);
long test_logicalNeg(long);
